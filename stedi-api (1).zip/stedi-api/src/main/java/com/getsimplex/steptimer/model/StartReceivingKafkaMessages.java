//© 2021 Sean Murdock

package com.getsimplex.steptimer.model;

public class StartReceivingKafkaMessages {
}
