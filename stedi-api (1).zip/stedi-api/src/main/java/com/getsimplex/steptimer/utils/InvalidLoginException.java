package com.getsimplex.steptimer.utils;

public class InvalidLoginException extends Exception{

    public InvalidLoginException(String text){
        super(text);
    }
}
